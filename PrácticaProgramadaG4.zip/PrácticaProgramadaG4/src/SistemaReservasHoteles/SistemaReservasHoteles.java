package SistemaReservasHoteles;

import java.util.*;

class Persona {
    private String nombre;
    private String primerApellido;
    private String segundoApellido;
    private String cedulaIdentidad;
    private String nacionalidad;
    private String telefono;
    private String correoElectronico;
    private String habitacionAsignada;

    public Persona(String nombre, String primerApellido, String segundoApellido, String cedulaIdentidad, String nacionalidad, String telefono, String correoElectronico) {
        this.nombre = nombre;
        this.primerApellido = primerApellido;
        this.segundoApellido = segundoApellido;
        this.cedulaIdentidad = cedulaIdentidad;
        this.nacionalidad = nacionalidad;
        this.telefono = telefono;
        this.correoElectronico = correoElectronico;
    }

    public String getHabitacionAsignada() {
        return habitacionAsignada;
    }

    public void setHabitacionAsignada(String habitacionAsignada) {
        this.habitacionAsignada = habitacionAsignada;
    }

    // Getters y setters para otros atributos
}

class Hotel {
    private String nombre;
    private int numTorres;
    private int numPisos;
    private int numHabitacionesPorPiso;
    private Map<Integer, Map<Integer, LinkedList<Integer>>> habitacionesDisponibles;

    public Hotel(String nombre, int numTorres, int numPisos, int numHabitacionesPorPiso) {
        this.nombre = nombre;
        this.numTorres = numTorres;
        this.numPisos = numPisos;
        this.numHabitacionesPorPiso = numHabitacionesPorPiso;
        this.habitacionesDisponibles = new HashMap<>();
        initializeHabitaciones();
    }

    private void initializeHabitaciones() {
        for (int torre = 1; torre <= numTorres; torre++) {
            Map<Integer, LinkedList<Integer>> pisos = new HashMap<>();
            for (int piso = 1; piso <= numPisos; piso++) {
                LinkedList<Integer> habitaciones = new LinkedList<>();
                for (int habitacion = 1; habitacion <= numHabitacionesPorPiso; habitacion++) {
                    habitaciones.add(habitacion);
                }
                pisos.put(piso, habitaciones);
            }
            habitacionesDisponibles.put(torre, pisos);
        }
    }

    public boolean reservarHabitacion(int torre, int piso, int habitacion) {
        if (torre >= 1 && torre <= numTorres && piso >= 1 && piso <= numPisos && habitacion >= 1 && habitacion <= numHabitacionesPorPiso) {
            LinkedList<Integer> habitaciones = habitacionesDisponibles.get(torre).get(piso);
            if (!habitaciones.isEmpty()) {
                habitaciones.removeFirst(); // Marcar habitación como no disponible
                return true; // Reserva exitosa
            }
        }
        return false; // No se pudo reservar la habitación
    }

    public boolean habitacionDisponible(int torre, int piso, int habitacion) {
        if (torre >= 1 && torre <= numTorres && piso >= 1 && piso <= numPisos && habitacion >= 1 && habitacion <= numHabitacionesPorPiso) {
            LinkedList<Integer> habitaciones = habitacionesDisponibles.get(torre).get(piso);
            return habitaciones.contains(habitacion);
        }
        return false; // Habitación no válida
    }

    public String getNombre() {
        return nombre;
    }

    public int getNumTorres() {
        return numTorres;
    }

    public int getNumPisos() {
        return numPisos;
    }

    public int getNumHabitacionesPorPiso() {
        return numHabitacionesPorPiso;
    }
}

public class SistemaReservasHoteles {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Hotel> hoteles = new ArrayList<>();
        // Crear los cuatro hoteles y agregarlos a la lista de hoteles
        hoteles.add(new Hotel("Hotel Continental de New York", 2, 5, 10));
        hoteles.add(new Hotel("Hotel Continental de Roma", 2, 5, 10));
        hoteles.add(new Hotel("Hotel Continental de Marruecos", 2, 5, 10));
        hoteles.add(new Hotel("Hotel Continental de Osaka Tokyo", 2, 5, 10));

        int opcion;
        do {
            System.out.println("Menu de Opciones Cadena de Hoteles Continental:");
            System.out.println("1. Listar todos los hoteles de la cadena");
            System.out.println("2. Listar todas las habitaciones disponibles por hotel");
            System.out.println("3. Registrar reservacion a una persona automaticamente");
            System.out.println("4. Registrar reservacion a una persona manualmente");
            System.out.println("5. Salir");
            System.out.print("Ingrese su opcion: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    // Listar todos los hoteles de la cadena
                    System.out.println("Lista de Hoteles:");
                    for (int i = 0; i < hoteles.size(); i++) {
                        System.out.println((i + 1) + ". " + hoteles.get(i).getNombre());
                    }
                    break;
                case 2:
                    // Listar habitaciones disponibles (Submenú)
                    listarHabitacionesDisponibles(hoteles, scanner);
                    break;
                case 3:
                    // Registrar reservación automáticamente
                    registrarReservacionAutomatica(hoteles, scanner);
                    System.out.println("Gracias por reservar automaticamente!");
                    break;
                case 4:
                    // Registrar reservación manualmente
                    registrarReservacionManual(hoteles, scanner);
                    break;

                case 5:
                    System.out.println("Gracias por usar el sistema de gestión de reservaciones!");
                    break;
                default:
                    System.out.println("Opcion no valida. Intente de nuevo.");
                    break;
            }
        } while (opcion != 5);

        scanner.close();
    }

    private static void listarHabitacionesDisponibles(List<Hotel> hoteles, Scanner scanner) {
        System.out.println("Lista de Hoteles:");
        for (int i = 0; i < hoteles.size(); i++) {
            System.out.println((i + 1) + ". " + hoteles.get(i).getNombre());
        }

        System.out.print("Seleccione un hotel (1-" + hoteles.size() + "): ");
        int hotelSeleccionado = scanner.nextInt();

        if (hotelSeleccionado >= 1 && hotelSeleccionado <= hoteles.size()) {
            Hotel hotel = hoteles.get(hotelSeleccionado - 1);

            System.out.println("Disponibilidad de Habitaciones en " + hotel.getNombre() + ":");
            for (int torre = 1; torre <= hotel.getNumTorres(); torre++) {
                for (int piso = 1; piso <= hotel.getNumPisos(); piso++) {
                    for (int habitacion = 1; habitacion <= hotel.getNumHabitacionesPorPiso(); habitacion++) {
                        boolean disponible = hotel.habitacionDisponible(torre, piso, habitacion);
                        String estado = disponible ? "Disponible" : "Ocupada";
                        System.out.println("Torre " + torre + ", Piso " + piso + ", Habitacion " + habitacion + ": " + estado);
                    }
                }
            }
        } else {
            System.out.println("Hotel seleccionado no válido.");
        }
    }

    private static void registrarReservacionAutomatica(List<Hotel> hoteles, Scanner scanner) {
        // Lógica para registrar reservación automáticamente (como se mencionó anteriormente)
    }

    private static void registrarReservacionManual(List<Hotel> hoteles, Scanner scanner) {
        // Solicitar información de la persona
        System.out.print("Nombre: ");
        String nombre = scanner.next();
        System.out.print("Primer Apellido: ");
        String primerApellido = scanner.next();
        System.out.print("Segundo Apellido: ");
        String segundoApellido = scanner.next();
        System.out.print("Cédula de Identidad: ");
        String cedulaIdentidad = scanner.next();
        System.out.print("Nacionalidad: ");
        String nacionalidad = scanner.next();
        System.out.print("Teléfono: ");
        String telefono = scanner.next();
        System.out.print("Correo Electrónico: ");
        String correoElectronico = scanner.next();

        // Seleccionar un hotel
        System.out.println("Lista de Hoteles:");
        for (int i = 0; i < hoteles.size(); i++) {
            System.out.println((i + 1) + ". " + hoteles.get(i).getNombre());
        }
        System.out.print("Seleccione un hotel (1-" + hoteles.size() + "): ");
        int hotelSeleccionado = scanner.nextInt();

        if (hotelSeleccionado >= 1 && hotelSeleccionado <= hoteles.size()) {
            Hotel hotel = hoteles.get(hotelSeleccionado - 1);

            // Seleccionar una torre, piso y habitación específica
            System.out.print("Seleccione la torre (1-" + hotel.getNumTorres() + "): ");
            int torre = scanner.nextInt();
            System.out.print("Seleccione el piso (1-" + hotel.getNumPisos() + "): ");
            int piso = scanner.nextInt();
            System.out.print("Seleccione el numero de habitacion (1-" + hotel.getNumHabitacionesPorPiso() + "): ");
            int habitacion = scanner.nextInt();

            // Verificar si la habitación está disponible y reservarla
            if (hotel.reservarHabitacion(torre, piso, habitacion)) {
                String habitacionAsignada = hotel.getNombre() + ", Torre " + torre + ", Piso " + piso + ", Habitación " + habitacion;
                Persona persona = new Persona(nombre, primerApellido, segundoApellido, cedulaIdentidad, nacionalidad, telefono, correoElectronico);
                persona.setHabitacionAsignada(habitacionAsignada);
                System.out.println("Reserva exitosa para " + nombre + ". Habitacion asignada: " + habitacionAsignada);
            } else {
                System.out.println("La habitación seleccionada no esta disponible.");
            }
        } else {
            System.out.println("Hotel seleccionado no valido.");
        }
    }
}